package Models;

public class ProductCategory {

    public static String getProductCategory() {
        return productCategory;
    }

    public static void setProductCategory(String productCategory) {
        ProductCategory.productCategory = productCategory;
    }

    public static String productCategory;


}
